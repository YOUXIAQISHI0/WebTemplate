(function(angular) {
    'use strict';

    //// JavaScript Code ////

    //// Angular Code ////
    angular.module('ngJsTreeDemo',['ngJsTree','toaster','cgBusy']);
})(angular);